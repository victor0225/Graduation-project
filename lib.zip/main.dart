import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:ui' as ui;
import 'dart:math';
import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:audioplayers/audioplayers.dart';

import 'firebase_options.dart';
import 'models/map_node.dart';
import 'services/astar_pathfinder.dart';
import 'services/map_analyzer.dart';
import 'services/flood_fill_handler.dart';
import 'services/kalman_filter.dart';
import 'widgets/map_painter.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  runApp(const MaterialApp(home: BluetoothApp()));
}

class BluetoothApp extends StatefulWidget {
  const BluetoothApp({super.key});
  @override
  State<BluetoothApp> createState() => _BluetoothAppState();
}

class _BluetoothAppState extends State<BluetoothApp> {
  Offset? userPosition;
  Map<int, Offset?> beaconPositions = {1: null, 2: null, 3: null};
  ui.Image? _loadedImage;

  // 지도 원본 크기
  final double mapWidth = 1046;
  final double mapHeight = 757;
  final int gridSize = 10;

  // ✅ InteractiveViewer의 pan/zoom 상태를 추적하는 컨트롤러
  final TransformationController _transformController =
      TransformationController();
  // ✅ InteractiveViewer의 화면상 위치를 알기 위한 Key
  final GlobalKey _viewerKey = GlobalKey();

  Map<String, MapNode> gridData = {};
  List<Offset> currentPath = [];

  bool isEditMode = false;
  bool isFillMode = false;
  dynamic _selectedTool = "move";

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final AudioPlayer _audioPlayer = AudioPlayer();
  StreamSubscription? _accelSubscription,
      _magSubscription,
      _fireAlarmSubscription;
  final KalmanFilter _accelFilter = KalmanFilter(0.001, 0.1, 0.0);

  double _userHeading = 0.0;
  int _stepCount = 0;
  bool _isStepDetected = false;
  bool _isPdrActive = false;
  bool _isFireAlertActive = false;
  bool _isNavigationMode = false;

  @override
  void initState() {
    super.initState();
    _setupPushNotifications();
    _listenToFireAlarm();
    _initializeMapAnalysis();
  }

  @override
  void dispose() {
    _transformController.dispose();
    _fireAlarmSubscription?.cancel();
    _accelSubscription?.cancel();
    _magSubscription?.cancel();
    super.dispose();
  }

  // --- [Firebase & 알림 로직] ---
  void _setupPushNotifications() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    await messaging.requestPermission(alert: true, badge: true, sound: true);
    FirebaseMessaging.instance.subscribeToTopic('fire_alerts');

    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');
    await flutterLocalNotificationsPlugin.initialize(
      settings: const InitializationSettings(
        android: initializationSettingsAndroid,
      ),
      onDidReceiveNotificationResponse: (response) {
        if (response.payload == 'emergency') _startEmergencyMode();
      },
    );
  }

  void _listenToFireAlarm() {
    _fireAlarmSubscription = _firestore
        .collection('status')
        .doc('fire_system')
        .snapshots()
        .listen((sn) {
          if (sn.exists && sn.get('is_fire') == true && !_isFireAlertActive) {
            _showFireAlert();
          }
        });
  }

  void _showFireAlert() {
    setState(() => _isFireAlertActive = true);
    _audioPlayer.play(AssetSource('fire_alarm.mp3'));
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text("🚨 화재 발생!"),
        content: const Text("대피 안내를 시작할까요?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("닫기"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _startEmergencyMode();
            },
            child: const Text("대피 시작"),
          ),
        ],
      ),
    );
  }

  void _startEmergencyMode() {
    setState(() {
      _isFireAlertActive = false;
      _isNavigationMode = true;
      isEditMode = false;
    });
    if (!_isPdrActive) _togglePdr();
    _calculatePath();
  }

  void _initializeMapAnalysis() async {
    final ByteData data = await rootBundle.load('assets/map_7_floor.png');
    final ui.Codec codec = await ui.instantiateImageCodec(
      data.buffer.asUint8List(),
    );
    final ui.FrameInfo fi = await codec.getNextFrame();

    final Map<String, MapNode> analyzed = await MapAnalyzer.analyzeImage(
      image: fi.image,
      gridSize: gridSize,
      threshold: 0.3,
    );

    setState(() {
      gridData = analyzed;
      _loadedImage = fi.image; // ✅ 이미지 저장
    });
  }

  // ✅ 핵심 수정: TransformationController로 역변환하여 진짜 지도 좌표 계산
  void _handleMapTap(PointerEvent event) {
    if (_selectedTool == "move") return;

    final RenderBox? viewerBox =
        _viewerKey.currentContext?.findRenderObject() as RenderBox?;
    if (viewerBox == null) return;

    // 화면 절대 좌표 -> InteractiveViewer 로컬 좌표 변환
    final Offset localToViewer = viewerBox.globalToLocal(event.position);

    // ✅ 역변환 행렬을 통해 줌/팬이 적용된 실제 지도상의 좌표 추출
    final Matrix4 inverse = Matrix4.inverted(_transformController.value);
    final Offset mapPos = MatrixUtils.transformPoint(inverse, localToViewer);

    // 지도 범위 밖(원본 크기 밖) 터치 무시 방지
    // 만약 지도 밖에도 그리드를 그리고 싶다면 아래 조건문을 주석 처리하세요.
    /*
  if (mapPos.dx < 0 || mapPos.dx > mapWidth || mapPos.dy < 0 || mapPos.dy > mapHeight) return;
  */

    int gx = (mapPos.dx / gridSize).floor();
    int gy = (mapPos.dy / gridSize).floor();
    String key = "$gx,$gy";

    setState(() {
      if (isFillMode) {
        // FloodFillHandler.fill(gridData, gx, gy, _selectedTool is NodeType ? _selectedTool : NodeType.wall);
      } else if (_selectedTool == "delete") {
        gridData.remove(key);
      } else if (_selectedTool == "user") {
        userPosition = Offset(
          (gx * gridSize) + (gridSize / 2),
          (gy * gridSize) + (gridSize / 2),
        );
      } else if (_selectedTool is String &&
          _selectedTool.startsWith("beacon_")) {
        int id = int.parse(_selectedTool.split("_")[1]);
        beaconPositions[id] = Offset(
          (gx * gridSize) + (gridSize / 2),
          (gy * gridSize) + (gridSize / 2),
        );
      } else if (_selectedTool is NodeType) {
        gridData[key] = MapNode(gx, gy, type: _selectedTool);
      }
    });
  }

  // --- [PDR 로직] ---
  void _togglePdr() {
    setState(() {
      _isPdrActive = !_isPdrActive;
      if (_isPdrActive) {
        _accelSubscription = accelerometerEventStream().listen(_onAccelEvent);
        _magSubscription = magnetometerEventStream().listen(
          (e) => setState(() => _userHeading = atan2(e.y, e.x)),
        );
      } else {
        _accelSubscription?.cancel();
        _magSubscription?.cancel();
      }
    });
  }

  void _onAccelEvent(AccelerometerEvent event) {
    double magnitude = sqrt(
      event.x * event.x + event.y * event.y + event.z * event.z,
    );
    double filtered = _accelFilter.filter(magnitude);
    if (filtered > 13.0 && !_isStepDetected) {
      setState(() {
        _isStepDetected = true;
        _stepCount++;
        if (userPosition != null) {
          userPosition =
              userPosition! +
              Offset(10 * cos(_userHeading), 10 * sin(_userHeading));
          _calculatePath();
        }
      });
    } else if (filtered < 11.0) {
      _isStepDetected = false;
    }
  }

  void _calculatePath() {
    if (userPosition == null || beaconPositions[1] == null) return;
    setState(() {
      currentPath = AStarPathfinder(
        gridSize,
      ).findPath(userPosition!, beaconPositions[1]!, gridData);
    });
  }

  // --- [UI Build] ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _isNavigationMode
              ? "🚨 긴급 대피 중"
              : (isEditMode ? "지도 편집" : "대피 안내 시스템"),
        ),
        backgroundColor: _isNavigationMode
            ? Colors.red
            : (isEditMode ? Colors.orange : Colors.blue),
      ),
      body: Column(
        children: [
          _buildStatusBar(),
          Expanded(child: _buildMapArea()),
          _buildControlPanel(),
        ],
      ),
    );
  }

  Widget _buildStatusBar() => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(8),
    color: _isNavigationMode ? Colors.red.shade100 : Colors.green.shade50,
    child: Text(
      _isNavigationMode ? "위험! 경로를 따라 이동하세요" : "화재 감시 시스템 정상",
      textAlign: TextAlign.center,
      style: const TextStyle(fontWeight: FontWeight.bold),
    ),
  );

  Widget _buildMapArea() {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Listener(
          // ✅ 터치 이벤트 감지 (역변환 로직 유지)
          behavior: HitTestBehavior.opaque,
          onPointerDown: (event) => _handleMapTap(event),
          onPointerMove: (event) {
            if (_selectedTool is NodeType || _selectedTool == "delete") {
              _handleMapTap(event);
            }
          },
          child: InteractiveViewer(
            key: _viewerKey,
            transformationController: _transformController,
            maxScale: 5.0,
            minScale: 0.1,
            // ✅ 여백을 넉넉히 주어 지도를 넘어서도 이동 가능하게 함
            boundaryMargin: const EdgeInsets.all(2000),
            panEnabled: _selectedTool == "move",
            scaleEnabled: _selectedTool == "move",
            child: OverflowBox(
              // ✅ 부모의 제약을 무시하고 원본 크기를 강제함
              minWidth: mapWidth,
              maxWidth: mapWidth,
              minHeight: mapHeight,
              maxHeight: mapHeight,
              alignment: Alignment.topLeft,
              child: SizedBox(
                width: mapWidth,
                height: mapHeight,
                child: Stack(
                  children: [
                    // 1. 배경 이미지 (원본 크기 유지 및 리사이징 방지)
                    Image.asset(
                      'assets/map_7_floor.png',
                      width: mapWidth,
                      height: mapHeight,
                      fit: BoxFit.none,
                      alignment: Alignment.topLeft,
                    ),
                    // 2. 그리드 및 경로 레이어
                    Positioned.fill(
                      child: CustomPaint(
                        painter: MapPainter(
                          gridData: gridData,
                          path: currentPath,
                          gridSize: gridSize,
                          isEditMode: isEditMode,
                          // 만약 Painter에서 이미지를 직접 그린다면 여기에 _loadedImage 전달
                        ),
                      ),
                    ),
                    ..._buildMappedIcons(),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  List<Widget> _buildMappedIcons() {
    List<Widget> icons = [];
    if (userPosition != null) {
      icons.add(
        Positioned(
          left: userPosition!.dx - 15,
          top: userPosition!.dy - 15,
          child: Transform.rotate(
            angle: _userHeading,
            child: const Icon(Icons.navigation, color: Colors.blue, size: 30),
          ),
        ),
      );
    }
    beaconPositions.forEach((id, pos) {
      if (pos != null) {
        icons.add(
          Positioned(
            left: pos.dx - 12,
            top: pos.dy - 12,
            child: Column(
              children: [
                Icon(Icons.bluetooth, color: Colors.orange.shade800, size: 24),
                Text(
                  "B$id",
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      }
    });
    return icons;
  }

  Widget _buildControlPanel() => Container(
    padding: const EdgeInsets.all(12),
    child: isEditMode ? _buildEditPanel() : _buildNavPanel(),
  );

  Widget _buildEditPanel() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _buildToolChip("move", Icons.open_with, "이동"),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: FilterChip(
                  label: const Text("채우기"),
                  selected: isFillMode,
                  onSelected: (val) => setState(() => isFillMode = val),
                  selectedColor: Colors.lightBlueAccent,
                ),
              ),
              _buildToolChip("delete", Icons.delete, "삭제", color: Colors.red),
              const VerticalDivider(),
              _buildToolChip(
                "user",
                Icons.person_pin_circle,
                "유저",
                color: Colors.blue,
              ),
              _buildToolChip(
                "beacon_1",
                Icons.bluetooth,
                "B1",
                color: Colors.orange,
              ),
              _buildToolChip(
                "beacon_2",
                Icons.bluetooth,
                "B2",
                color: Colors.orange,
              ),
              _buildToolChip(
                "beacon_3",
                Icons.bluetooth,
                "B3",
                color: Colors.orange,
              ),
              const VerticalDivider(),
              ...NodeType.values
                  .where((t) => t != NodeType.empty)
                  .map(
                    (type) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(
                        label: Text(type.name),
                        selected: _selectedTool == type,
                        onSelected: (_) => setState(() => _selectedTool = type),
                      ),
                    ),
                  ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        ElevatedButton(
          onPressed: () => setState(() {
            isEditMode = false;
            _selectedTool = "move";
          }),
          child: const Text("편집 완료"),
        ),
      ],
    );
  }

  Widget _buildToolChip(
    dynamic toolId,
    IconData icon,
    String label, {
    Color? color,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ActionChip(
        avatar: Icon(icon, size: 16, color: color),
        label: Text(label),
        onPressed: () => setState(() => _selectedTool = toolId),
        backgroundColor: _selectedTool == toolId ? Colors.blue.shade100 : null,
      ),
    );
  }

  Widget _buildNavPanel() => Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [
      Text("걸음: $_stepCount"),
      ElevatedButton(
        onPressed: () => setState(() {
          isEditMode = true;
          _selectedTool = "move";
        }),
        child: const Text("지도 수정"),
      ),
      ElevatedButton(onPressed: _calculatePath, child: const Text("경로 재계산")),
    ],
  );
}
