enum NodeType {
  wall, // 벽 (통과 불가)
  path, // 복도 (통과 가능)
  room, // 일반 방 (통과 불가 공간)
  residence, // 내 집 (통과 가능/시작점 후보)
  exit, // 비상구 (목적지)
  empty, // 설정되지 않은 공간
}

class MapNode {
  final int x, y;
  NodeType type;
  // A*를 위한 변수들
  double gCost = 0;
  double hCost = 0;
  MapNode? parent;

  double get fCost => gCost + hCost;

  MapNode(this.x, this.y, {this.type = NodeType.empty});

  Map<String, dynamic> toJson() => {'x': x, 'y': y, 'type': type.index};

  factory MapNode.fromJson(Map<String, dynamic> json) {
    return MapNode(
      json['x'] as int,
      json['y'] as int,
      type: NodeType.values[json['type'] ?? 5],
    );
  }
}
