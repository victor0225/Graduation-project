class KalmanFilter {
  final double _processNoise; // 프로세스 노이즈 (Q)
  final double _measurementNoise; // 측정 노이즈 (R)
  double _estimatedValue; // 추정값
  double _errorCovariance = 1.0; // 오차 공분산 (P)

  KalmanFilter(
    this._processNoise,
    this._measurementNoise,
    this._estimatedValue,
  );

  /// 측정값을 입력받아 필터링된 추정값을 반환합니다.
  double filter(double measurement) {
    // 1. 예측 (Prediction)
    _errorCovariance = _errorCovariance + _processNoise;

    // 2. 업데이트 (Update)
    double kalmanGain =
        _errorCovariance / (_errorCovariance + _measurementNoise);
    _estimatedValue =
        _estimatedValue + kalmanGain * (measurement - _estimatedValue);
    _errorCovariance = (1 - kalmanGain) * _errorCovariance;

    return _estimatedValue;
  }
}
