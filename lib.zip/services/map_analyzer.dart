import 'dart:ui' as ui;
import 'package:flutter/services.dart';
import '../models/map_node.dart';

class MapAnalyzer {
  /// 이미지를 분석하여 그리드 맵 데이터를 생성합니다.
  /// [image]: 분석할 ui.Image 객체
  /// [gridSize]: 한 칸의 크기
  /// [threshold]: 벽으로 판단할 밝기 기준 (0.0~1.0, 낮을수록 검은색만 벽으로 인식)
  static Future<Map<String, MapNode>> analyzeImage({
    required ui.Image image,
    required int gridSize,
    double threshold = 0.6,
  }) async {
    final Map<String, MapNode> analyzedGrid = {};

    // 이미지의 픽셀 데이터를 RGBA 리스트로 가져옴
    final ByteData? byteData = await image.toByteData(
      format: ui.ImageByteFormat.rawRgba,
    );
    if (byteData == null) return analyzedGrid;

    final int width = image.width;
    final int height = image.height;

    // 그리드 단위로 루프를 돌며 중앙 픽셀의 밝기 체크
    for (int y = 0; y < height; y += gridSize) {
      for (int x = 0; x < width; x += gridSize) {
        // 해당 그리드의 중심부 픽셀 좌표 계산
        int centerX = x + (gridSize ~/ 2);
        int centerY = y + (gridSize ~/ 2);

        // 범위를 벗어나지 않도록 보정
        if (centerX >= width) centerX = width - 1;
        if (centerY >= height) centerY = height - 1;

        // RGBA 데이터에서 해당 픽셀의 인덱스 계산 (4바이트씩)
        int offset = (centerY * width + centerX) * 4;

        int r = byteData.getUint8(offset);
        int g = byteData.getUint8(offset + 1);
        int b = byteData.getUint8(offset + 2);

        // 밝기 계산 (표준 휘도 공식)
        double brightness = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0;

        int gx = x ~/ gridSize;
        int gy = y ~/ gridSize;
        String key = "$gx,$gy";

        // 밝기가 기준값보다 낮으면(어두우면) 벽, 높으면 방으로 간주
        if (brightness < threshold) {
          analyzedGrid[key] = MapNode(gx, gy, type: NodeType.wall);
        } else {
          analyzedGrid[key] = MapNode(gx, gy, type: NodeType.room);
        }
      }
    }
    return analyzedGrid;
  }
}
