import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/map_node.dart';

class MapManager {
  static const String _mapKey = 'saved_grid_map';

  // 지도 데이터를 SharedPreferences에 저장
  static Future<void> saveMap(Map<String, MapNode> gridData) async {
    final prefs = await SharedPreferences.getInstance();
    Map<String, dynamic> jsonMap = {};
    gridData.forEach((key, value) => jsonMap[key] = value.toJson());
    await prefs.setString(_mapKey, jsonEncode(jsonMap));
  }

  // 저장된 지도 데이터를 불러오기
  static Future<Map<String, MapNode>> loadMap() async {
    final prefs = await SharedPreferences.getInstance();
    String? data = prefs.getString(_mapKey);
    if (data == null) return {};

    Map<String, dynamic> decoded = jsonDecode(data);
    return decoded.map((k, v) => MapEntry(k, MapNode.fromJson(v)));
  }

  // 지도 초기화
  static Future<void> clearMap() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_mapKey);
  }
}
