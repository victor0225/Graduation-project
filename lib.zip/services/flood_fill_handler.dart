import 'dart:collection';
import '../models/map_node.dart';

class FloodFillHandler {
  /// 특정 좌표부터 시작하여 인접한 빈 공간을 선택한 타입으로 채웁니다.
  static Map<String, MapNode> fill({
    required int startX,
    required int startY,
    required NodeType targetType,
    required Map<String, MapNode> grid,
    int maxGridX = 200,
    int maxGridY = 200,
  }) {
    // 이미 벽이거나 같은 타입이면 무시
    String startKey = "$startX,$startY";
    if (!grid.containsKey(startKey) || grid[startKey]!.type == NodeType.wall) {
      return grid;
    }

    NodeType originalType = grid[startKey]!.type;
    if (originalType == targetType) return grid;

    Queue<List<int>> queue = Queue();
    queue.add([startX, startY]);

    while (queue.isNotEmpty) {
      List<int> current = queue.removeFirst();
      int x = current[0];
      int y = current[1];
      String key = "$x,$y";

      // 범위를 벗어나거나, 이미 처리되었거나, 벽인 경우 스킵
      if (x < 0 || x >= maxGridX || y < 0 || y >= maxGridY) continue;
      if (!grid.containsKey(key) || grid[key]!.type != originalType) continue;

      // 타입 변경
      grid[key]!.type = targetType;

      // 4방향 탐색 (상하좌우)
      queue.add([x + 1, y]);
      queue.add([x - 1, y]);
      queue.add([x, y + 1]);
      queue.add([x, y - 1]);
    }
    return grid;
  }
}
