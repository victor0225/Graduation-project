import 'package:flutter/material.dart';
import 'dart:math';
import '../models/map_node.dart';

class AStarPathfinder {
  final int gridSize;
  AStarPathfinder(this.gridSize);

  List<Offset> findPath(
    Offset start,
    Offset target,
    Map<String, MapNode> grid,
  ) {
    int startX = (start.dx / gridSize).floor();
    int startY = (start.dy / gridSize).floor();
    int targetX = (target.dx / gridSize).floor();
    int targetY = (target.dy / gridSize).floor();

    List<MapNode> openSet = [];
    Set<String> closedSet = {};

    openSet.add(MapNode(startX, startY, type: NodeType.path));

    while (openSet.isNotEmpty) {
      MapNode current = openSet.reduce((a, b) => a.fCost < b.fCost ? a : b);
      openSet.remove(current);
      closedSet.add("${current.x},${current.y}");

      if (current.x == targetX && current.y == targetY) {
        return _retracePath(current);
      }

      for (int dx = -1; dx <= 1; dx++) {
        for (int dy = -1; dy <= 1; dy++) {
          if (dx == 0 && dy == 0) continue;

          int nextX = current.x + dx;
          int nextY = current.y + dy;
          String key = "$nextX,$nextY";

          // 이동 가능 조건: 그리드 내 존재 && (복도 OR 거주지 OR 비상구) && 미방문
          if (grid.containsKey(key) &&
              (grid[key]!.type == NodeType.path ||
                  grid[key]!.type == NodeType.residence ||
                  grid[key]!.type == NodeType.exit) &&
              !closedSet.contains(key)) {
            MapNode neighbor = MapNode(nextX, nextY);
            double newCost =
                current.gCost + (dx.abs() + dy.abs() == 2 ? 1.4 : 1.0);

            if (newCost < neighbor.gCost ||
                !openSet.any((n) => n.x == nextX && n.y == nextY)) {
              neighbor.gCost = newCost;
              neighbor.hCost = sqrt(
                pow(nextX - targetX, 2) + pow(nextY - targetY, 2),
              );
              neighbor.parent = current;

              if (!openSet.any((n) => n.x == nextX && n.y == nextY)) {
                openSet.add(neighbor);
              }
            }
          }
        }
      }
    }
    return [];
  }

  List<Offset> _retracePath(MapNode endNode) {
    List<Offset> path = [];
    MapNode? temp = endNode;
    while (temp != null) {
      path.add(
        Offset(
          (temp.x * gridSize) + (gridSize / 2),
          (temp.y * gridSize) + (gridSize / 2),
        ),
      );
      temp = temp.parent;
    }
    return path.reversed.toList();
  }
}
