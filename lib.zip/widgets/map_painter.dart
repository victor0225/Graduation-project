import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import '../models/map_node.dart';

class MapPainter extends CustomPainter {
  final Map<String, MapNode> gridData;
  final List<Offset> path;
  final int gridSize;
  final bool isEditMode;

  MapPainter({
    required this.gridData,
    required this.path,
    required this.gridSize,
    required this.isEditMode,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..strokeWidth = 0.5; // ✅ 선 두께를 얇게 조정

    if (isEditMode) {
      // 1. 그리드 격자 그리기
      paint.color = Colors.grey.withOpacity(0.3);
      for (double x = 0; x <= size.width; x += gridSize) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
      }
      for (double y = 0; y <= size.height; y += gridSize) {
        canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
      }

      // 2. 저장된 노드(벽 등) 그리기
      gridData.forEach((key, node) {
        paint.color = _getNodeColor(node.type);
        canvas.drawRect(
          Rect.fromLTWH(
            node.x * gridSize.toDouble(),
            node.y * gridSize.toDouble(),
            gridSize.toDouble(),
            gridSize.toDouble(),
          ),
          paint,
        );
      });
    }

    // 3. 대피 경로 그리기
    if (path.isNotEmpty) {
      final pathPaint = Paint()
        ..color = Colors.red
        ..strokeWidth = 3.0
        ..style = PaintingStyle.stroke;

      final polyline = Path();
      polyline.moveTo(path[0].dx, path[0].dy);
      for (var i = 1; i < path.length; i++) {
        polyline.lineTo(path[i].dx, path[i].dy);
      }
      canvas.drawPath(polyline, pathPaint);
    }
  }

  Color _getNodeColor(NodeType type) {
    switch (type) {
      case NodeType.wall:
        return Colors.black.withOpacity(0.5);
      case NodeType.exit:
        return Colors.green.withOpacity(0.5);
      default:
        return Colors.transparent;
    }
  }

  @override
  bool shouldRepaint(MapPainter oldDelegate) => true;
}
